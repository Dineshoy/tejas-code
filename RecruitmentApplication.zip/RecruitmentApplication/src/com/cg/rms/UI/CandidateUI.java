package com.cg.rms.UI;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.rms.dto.Recruitment;
import com.cg.rms.exception.RecruitmentException;
import com.cg.rms.service.CourseService;
import com.cg.rms.service.CourseServiceImpl;

public class CandidateUI {

public void candidateUimethod() throws RecruitmentException {
		Scanner sc = new Scanner(System.in);
		CourseService cser = new CourseServiceImpl();
		
		String role="candidate";

		
		
		System.out.println("********Candidate Login Page*********");
		System.out.println();
		System.out.println();
		System.out.println("Enter your login id:");
		String username=sc.next();
		System.out.println("Enter your password:");
		String password=sc.next();
		

		
		try {
			int value=cser.login(username, password, role);
			
			if(value == 2)
			{
				System.out.println("Wrong Credentials.Please try again");
			}
			if(value==1)
			{
				
				System.out.println("welcome Candidate");
			}
		}
			
			catch (RecruitmentException e)
			{
				throw new RecruitmentException("Wrong credentials.Please retry.");
			}
		
		
do {
	System.out.println("menu");
System.out.println("1. show all candidate details");
System.out.println("2. Add new candidate Details");
/*System.out.println("3. delete a course");*/
System.out.println("3. update candidate Details");
System.out.println("4. exit");
int choice = sc.nextInt();
switch (choice) {
case 1:
	try {
		List<Recruitment> clist = cser.getAllCourses();
		for (Recruitment c:clist) {
			System.out.println(c);
		}
	} catch (RecruitmentException e) {
		System.err.println(e.getMessage());
		
		//e.printStackTrace();
	}
	break;
case 2:
	Recruitment c = new Recruitment();
	System.out.println("enter candidate name");
	c.setCandidate_name(sc.next());
	System.out.println("enter candidate address");
	c.setAddress(sc.next());
	System.out.println("enter DOB");
	
	c.setDOB(sc.next());
	System.out.println("Enter email ID");
	c.setEmail_id(sc.next());
	System.out.println("enter contact no");
	c.setContact_number(sc.next());
	System.out.println("enter maritial status");
	c.setMaritial_status(sc.next());
	System.out.println("Enter Gender");
	c.setGender(sc.next());
    System.out.println("Enter Passport no");
    c.setPassport_number(sc.next());
    
    String cid;
	try {
		cid = cser.insertCourse(c);
		System.out.println("course added with ID"+cid);
	} catch (RecruitmentException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
	break;

case 3:
	System.out.println("enter the course  Id to update the details ");
	Recruitment c1 = new Recruitment();
	try {
		boolean b = cser.updateCourse(c1);
		if(b) {
			System.out.println("Details updated s");
		}
	} catch (RecruitmentException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	break;
case 4:
	
	break;

default:System.out.println("invalid choice");
	
	break;
}
} while (true);
	
	}
}
