package com.cg.rms.dto;

public class Recruitment {

	private String candidate_id;
	private String candidate_name;
	private String address;
	private String DOB;
	private String email_id;
	private String contact_number;
	private String Maritial_status;
	private String Gender;
	private String Passport_number;
	
	
	public Recruitment() {
		super();
	}

	

	public Recruitment(String candidate_id, String candidate_name, String address,
			String dOB, String email_id, String contact_number,
			String maritial_status, String gender, String passport_number) {
		super();
		this.candidate_id = candidate_id;
		this.candidate_name = candidate_name;
		this.address = address;
		DOB = dOB;
		this.email_id = email_id;
		this.contact_number = contact_number;
		Maritial_status = maritial_status;
		Gender = gender;
		Passport_number = passport_number;
	}



	
	public String getCandidate_id() {
		return candidate_id;
	}



	public void setCandidate_id(String candidate_id) {
		this.candidate_id = candidate_id;
	}



	public String getCandidate_name() {
		return candidate_name;
	}



	public void setCandidate_name(String candidate_name) {
		this.candidate_name = candidate_name;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public String getDOB() {
		return DOB;
	}



	public void setDOB(String dOB) {
		DOB = dOB;
	}



	public String getEmail_id() {
		return email_id;
	}



	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}



	public String getContact_number() {
		return contact_number;
	}



	public void setContact_number(String contact_number) {
		this.contact_number = contact_number;
	}



	public String getMaritial_status() {
		return Maritial_status;
	}



	public void setMaritial_status(String maritial_status) {
		Maritial_status = maritial_status;
	}



	public String getGender() {
		return Gender;
	}



	public void setGender(String gender) {
		Gender = gender;
	}



	public String getPassport_number() {
		return Passport_number;
	}



	public void setPassport_number(String passport_number) {
		Passport_number = passport_number;
	}



	@Override
	public String toString() {
		return "Course [candidate_id=" + candidate_id + ", candidate_name="
				+ candidate_name + ", address=" + address + ", DOB=" + DOB
				+ ", email_id=" + email_id + ", contact_number="
				+ contact_number + ", Maritial_status=" + Maritial_status
				+ ", Gender=" + Gender + ", Passport_number=" + Passport_number
				+ "]";
	}
	
}
