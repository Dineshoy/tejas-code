package com.cg.rms.dto;

import java.sql.Date;

public class CandidateWorkHistory {
	
	String work_id;
	 String candidate_id;
	 String which_employer;
	 String contact_person;
	 String position_held;
	 String company_name;
	String employement_from;
	String employement_to;
	 String reason_for_leaving;
	 String responsibilities;
	 String hr_rep_name;
	 String hr_rep_contact_num;
	 
	 public CandidateWorkHistory() {
			super();
			// TODO Auto-generated constructor stub
		}
		 
		 
	 
	 
	 
	public CandidateWorkHistory(String work_id, String candidate_id,
			String which_employer, String contact_person, String position_held,
			String company_name, String employement_from,
			String employement_to, String reason_for_leaving,
			String responsibilities, String hr_rep_name,
			String hr_rep_contact_num) {
		super();
		this.work_id = work_id;
		this.candidate_id = candidate_id;
		this.which_employer = which_employer;
		this.contact_person = contact_person;
		this.position_held = position_held;
		this.company_name = company_name;
		this.employement_from = employement_from;
		this.employement_to = employement_to;
		this.reason_for_leaving = reason_for_leaving;
		this.responsibilities = responsibilities;
		this.hr_rep_name = hr_rep_name;
		this.hr_rep_contact_num = hr_rep_contact_num;
	}





	public String getWork_id() {
		return work_id;
	}
	public void setWork_id(String work_id) {
		this.work_id = work_id;
	}
	public String getCandidate_id() {
		return candidate_id;
	}
	public void setCandidate_id(String candidate_id) {
		this.candidate_id = candidate_id;
	}
	public String getWhich_employer() {
		return which_employer;
	}
	public void setWhich_employer(String which_employer) {
		this.which_employer = which_employer;
	}
	public String getContact_person() {
		return contact_person;
	}
	public void setContact_person(String contact_person) {
		this.contact_person = contact_person;
	}
	public String getPosition_held() {
		return position_held;
	}
	public void setPosition_held(String position_held) {
		this.position_held = position_held;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public String  getEmployement_from() {
		return employement_from;
	}
	public void setEmployement_from(String employement_from) {
		this.employement_from = employement_from;
	}
	public String  getEmployement_to() {
		return employement_to;
	}
	public void setEmployement_to(String  employement_to) {
		this.employement_to = employement_to;
	}
	public String getReason_for_leaving() {
		return reason_for_leaving;
	}
	public void setReason_for_leaving(String reason_for_leaving) {
		this.reason_for_leaving = reason_for_leaving;
	}
	public String getResponsibilities() {
		return responsibilities;
	}
	public void setResponsibilities(String responsibilities) {
		this.responsibilities = responsibilities;
	}
	public String getHr_rep_name() {
		return hr_rep_name;
	}
	public void setHr_rep_name(String hr_rep_name) {
		this.hr_rep_name = hr_rep_name;
	}
	public String getHr_rep_contact_num() {
		return hr_rep_contact_num;
	}
	public void setHr_rep_contact_num(String hr_rep_contact_num) {
		this.hr_rep_contact_num = hr_rep_contact_num;
	}
	@Override
	public String toString() {
		return "CandidateWorkHistory [work_id=" + work_id + ", candidate_id=" + candidate_id + ", which_employer="
				+ which_employer + ", contact_person=" + contact_person + ", position_held=" + position_held
				+ ", company_name=" + company_name + ", employement_from=" + employement_from + ", employement_to="
				+ employement_to + ", reason_for_leaving=" + reason_for_leaving + ", responsibilities=" + responsibilities
				+ ", hr_rep_name=" + hr_rep_name + ", hr_rep_contact_num=" + hr_rep_contact_num + "]";
	}
	


}
